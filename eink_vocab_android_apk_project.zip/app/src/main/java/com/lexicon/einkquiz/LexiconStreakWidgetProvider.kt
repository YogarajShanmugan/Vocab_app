package com.lexicon.einkquiz

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class LexiconStreakWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    companion object {
        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, LexiconStreakWidgetProvider::class.java))
            for (id in ids) {
                updateWidget(context, manager, id)
            }
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("eink_lexicon_prefs", Context.MODE_PRIVATE)
            val streak = prefs.getInt("streak", 0)
            val done = prefs.getInt("quizzedToday", 0)
            val target = prefs.getInt("dailyGoalTarget", 10)
            val mastered = prefs.getInt("masteredCount", 0)

            val views = RemoteViews(context.packageName, R.layout.widget_streak_2x2)
            views.setTextViewText(R.id.widget_streak_number, streak.toString())
            views.setTextViewText(R.id.widget_streak_goal, "GOAL: $done/$target • $mastered MASTERED")
            views.setProgressBar(R.id.widget_streak_progress, target, done.coerceAtMost(target), false)

            val openIntent = Intent(context, MainActivity::class.java)
            val openPending = PendingIntent.getActivity(
                context, 2, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_streak_root, openPending)

            manager.updateAppWidget(widgetId, views)
        }
    }
}
