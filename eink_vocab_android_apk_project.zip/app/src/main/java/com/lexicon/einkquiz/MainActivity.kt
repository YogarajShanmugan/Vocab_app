package com.lexicon.einkquiz

import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidWidgetBridge(this), "AndroidWidgetBridge")

        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}

class AndroidWidgetBridge(private val context: Context) {

    @JavascriptInterface
    fun updateWidgetData(jsonPayload: String) {
        try {
            val obj = JSONObject(jsonPayload)
            val prefs = context.getSharedPreferences("eink_lexicon_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("word", obj.optString("word", "EPHEMERAL"))
                .putString("pos", obj.optString("pos", "ADJ"))
                .putString("phonetic", obj.optString("phonetic", "/ɪˈfɛm.ər.əl/"))
                .putString("def", obj.optString("def", "Lasting for a very short time; transitory."))
                .putInt("streak", obj.optInt("streak", 0))
                .putInt("quizzedToday", obj.optInt("quizzedToday", 0))
                .putInt("dailyGoalTarget", obj.optInt("dailyGoalTarget", 10))
                .putInt("masteredCount", obj.optInt("masteredCount", 0))
                .apply()

            // Trigger immediate refresh on all 3 E-Ink Home Screen Widgets
            LexiconWordWidgetProvider.updateAllWidgets(context)
            LexiconStreakWidgetProvider.updateAllWidgets(context)
            LexiconTickerWidgetProvider.updateAllWidgets(context)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
