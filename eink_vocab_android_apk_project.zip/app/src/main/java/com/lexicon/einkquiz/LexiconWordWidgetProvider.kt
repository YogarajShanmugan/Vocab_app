package com.lexicon.einkquiz

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class LexiconWordWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_NEXT_WIDGET_WORD) {
            cycleFallbackWord(context)
            updateAllWidgets(context)
        }
    }

    companion object {
        const val ACTION_NEXT_WIDGET_WORD = "com.lexicon.einkquiz.ACTION_NEXT_WIDGET_WORD"

        private val BUILTIN_WIDGET_WORDS = listOf(
            Triple("EPHEMERAL", "ADJ // /ɪˈfɛm.ər.əl/", "Lasting for a very short time; transitory."),
            Triple("PERSPICACIOUS", "ADJ // /ˌpɜː.spɪˈkeɪ.ʃəs/", "Having a ready insight into and understanding of things; shrewd."),
            Triple("PETRICHOR", "NOUN // /ˈpɛt.rɪ.kɔːr/", "A pleasant, earthy smell that accompanies the first rain after a dry spell."),
            Triple("EQUANIMITY", "NOUN // /ˌɛk.wəˈnɪm.ɪ.ti/", "Mental calmness, composure, and evenness of temper in a difficult situation."),
            Triple("VERISIMILITUDE", "NOUN // /ˌvɛr.ɪ.sɪˈmɪl.ɪ.tjuːd/", "The appearance of being true or real."),
            Triple("APRICITY", "NOUN // /əˈprɪs.ɪ.ti/", "The warmth of the sun in winter.")
        )

        private fun cycleFallbackWord(context: Context) {
            val prefs = context.getSharedPreferences("eink_lexicon_prefs", Context.MODE_PRIVATE)
            val nextIdx = (prefs.getInt("widget_idx", 0) + 1) % BUILTIN_WIDGET_WORDS.size
            val picked = BUILTIN_WIDGET_WORDS[nextIdx]
            prefs.edit()
                .putInt("widget_idx", nextIdx)
                .putString("word", picked.first)
                .putString("pos", picked.second)
                .putString("def", picked.third)
                .apply()
        }

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, LexiconWordWidgetProvider::class.java))
            for (id in ids) {
                updateWidget(context, manager, id)
            }
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("eink_lexicon_prefs", Context.MODE_PRIVATE)
            val word = prefs.getString("word", "EPHEMERAL") ?: "EPHEMERAL"
            val pos = prefs.getString("pos", "ADJ") ?: "ADJ"
            val def = prefs.getString("def", "Lasting for a very short time; transitory.") ?: ""
            val streak = prefs.getInt("streak", 0)
            val done = prefs.getInt("quizzedToday", 0)
            val target = prefs.getInt("dailyGoalTarget", 10)

            val views = RemoteViews(context.packageName, R.layout.widget_word_4x2)
            views.setTextViewText(R.id.widget_word_title, word)
            views.setTextViewText(R.id.widget_word_pos, pos)
            views.setTextViewText(R.id.widget_word_def, def)
            views.setTextViewText(R.id.widget_word_meta, "STREAK: ${streak}D • GOAL: $done/$target")

            // Tap card to open full E-Ink Quiz App
            val openIntent = Intent(context, MainActivity::class.java)
            val openPending = PendingIntent.getActivity(
                context, 0, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_word_root, openPending)

            // Tap "NEXT WORD ->" button to cycle word right on the home screen
            val nextIntent = Intent(context, LexiconWordWidgetProvider::class.java).apply {
                action = ACTION_NEXT_WIDGET_WORD
            }
            val nextPending = PendingIntent.getBroadcast(
                context, 1, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_next_word_btn, nextPending)

            manager.updateAppWidget(widgetId, views)
        }
    }
}
