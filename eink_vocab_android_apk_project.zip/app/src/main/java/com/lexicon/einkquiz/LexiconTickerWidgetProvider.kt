package com.lexicon.einkquiz

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class LexiconTickerWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    companion object {
        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, LexiconTickerWidgetProvider::class.java))
            for (id in ids) {
                updateWidget(context, manager, id)
            }
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("eink_lexicon_prefs", Context.MODE_PRIVATE)
            val word = prefs.getString("word", "EPHEMERAL") ?: "EPHEMERAL"
            val def = prefs.getString("def", "Lasting for a very short time; transitory.") ?: ""

            val views = RemoteViews(context.packageName, R.layout.widget_ticker_4x1)
            views.setTextViewText(R.id.widget_ticker_word, word)
            views.setTextViewText(R.id.widget_ticker_def, def)

            val openIntent = Intent(context, MainActivity::class.java)
            val openPending = PendingIntent.getActivity(
                context, 3, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_ticker_root, openPending)

            manager.updateAppWidget(widgetId, views)
        }
    }
}
