# E-Ink Lexicon Quiz — Android APK & Home Screen Widgets

This package contains the complete Android source project wrapping your **E-Ink Vocabulary Quiz** web app (`app/src/main/assets/index.html`) alongside **3 Native Android E-Ink Home Screen Widgets**:

1. **4×2 E-Ink Word of the Day Card (`LexiconWordWidgetProvider`)**: Shows the word, part of speech, definition, current streak, and a live `NEXT WORD →` button that flips words right on your Android home screen.
2. **2×2 E-Ink Streak & Goal Counter (`LexiconStreakWidgetProvider`)**: Displays your current streak number, progress bar, and mastered count.
3. **4×1 E-Ink Minimalist Ticker (`LexiconTickerWidgetProvider`)**: Compact 1-row vocabulary strip.

---

## Option A: Build the `.apk` in the Cloud for Free (No Android Studio Needed)

1. Create a free repository on [GitHub](https://github.com/new) and upload the contents of this `.zip` folder.
2. Click the **Actions** tab in your GitHub repository and select **Build E-Ink Lexicon Android APK** → **Run workflow**.
3. In about 90 seconds, download `eink-lexicon-quiz-debug-apk` (`app-debug.apk`) from the workflow summary and install it on your Android phone!

## Option B: Build in Android Studio on Your Computer

1. Open [Android Studio](https://developer.android.com/studio) and choose **Open** → select this extracted folder.
2. Wait for Gradle sync to finish, then click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone to install the app and add the 3 E-Ink widgets from your Android launcher's **Widgets** menu.
